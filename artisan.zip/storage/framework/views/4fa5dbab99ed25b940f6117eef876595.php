<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'CRIPADA'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body class="bg-gray-100 text-gray-900">

    <div class="container mx-auto py-6">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PROYECTOS CRIPADA\Acondicionamiento\API\api-acondicionamiento-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>