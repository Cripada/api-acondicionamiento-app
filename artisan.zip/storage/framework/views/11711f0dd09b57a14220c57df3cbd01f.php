

<?php if(session('success')): ?>
    <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ open: true }">
    <!-- Modal -->
    <div x-show="open" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 class="text-xl font-bold mb-4">Aprobar Proforma #<?php echo e($proforma->num_proforma ?? $proforma->idproforma); ?></h2>

            <form method="POST" action="<?php echo e(route('proformas.aprobar', $proforma->idproforma)); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label>Usuario (correo)</label>
                    <input type="text" name="correo" class="border p-2 w-full" required>
                </div>

                <div class="mb-3">
                    <label>Contraseña</label>
                    <input type="password" name="password" class="border p-2 w-full" required>
                </div>

                <div class="mb-3">
                    <label>Comentario</label>
                    <textarea name="comentario" class="border p-2 w-full"></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(url()->previous()); ?>" class="border px-4 py-2">Cancelar</a>
                    <button type="submit" class="bg-green-600 text-white px-4 py-2">Aprobar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTOS CRIPADA\Acondicionamiento\API\api-acondicionamiento-app\resources\views/proformas/aprobar.blade.php ENDPATH**/ ?>